import NotConnect from './../../Image/uncon.png';
import './../Sidebar/Sidebar.css';
function Alert(){


return(
<div >
<a href='./soon'>
<img id="alert" className="alert" src={NotConnect}/>
</a>
 </div>

);


}


export default Alert;