import './Soon.css';


function Soon(){
return(
    <div>
    
    <section>
      <h2>
      Coming Soon!
      </h2>
      <div className="bg">
       </div>
    </section>
  </div>



);
}
export default Soon;